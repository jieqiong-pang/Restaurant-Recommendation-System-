from pyspark import SparkContext, SparkConf, StorageLevel
import sys
import json
import re
import math
import time


train_file = sys.argv[1]
model_file = sys.argv[2]
stopwords_file = sys.argv[3]
conf = (
    SparkConf()
    .setAppName("inf553_hw3_task2train")
    .set("spark.executor.memory", "4g")
    .set("spark.driver.memory", "4g")
)
sc = SparkContext(conf=conf)

start = time.time()

stopwords = sc.textFile(stopwords_file).flatMap(lambda s: s.split()).collect()


# region item profile
def stop_words(b_words):
    # for each business,count the words
    business = b_words[0]
    words_lst = b_words[1]
    business_words = {}
    for word in words_lst:
        if word not in stopwords:
            if word not in business_words:
                business_words[word] = 1
            else:
                business_words[word] = business_words[word] + 1

    words = []
    for key, value in business_words.items():
        words.append((business, key, value))
    return words


# remove punctuations and number
# [(user_id,business_id,[words]),(user_id,business_id,[words]),(user_id,business_id,[words])...]
rdd = (
    sc.textFile(train_file)
    .map(json.loads)
    .map(
        lambda x: (
            x["user_id"],
            x["business_id"],
            re.sub("[0-9\W]", " ", x["text"]).lower().split(),
        )
    )
)

# remove stopwords
# [(business,word,fre),(business,word,fre),(business,word,fre)...]
concatenate = (
    rdd.map(lambda b: (b[1], b[2]))
    .reduceByKey(lambda u, v: u + v)
    .flatMap(lambda x: stop_words(x))
    .persist(storageLevel=StorageLevel.MEMORY_AND_DISK)
)
cnt = sum(concatenate.map(lambda x: x[2]).collect())
threshold = int(cnt * 0.0001 / 100)
rare = (
    concatenate.map(lambda x: (x[1], x[2]))
    .reduceByKey(lambda u, v: u + v)
    .filter(lambda x: x[1] < threshold)
)

N = rdd.map(lambda b: b[1]).distinct().count()
# ({word:cnt,word:cnt...})
merge = (
    concatenate.map(lambda x: (x[1], x[2]))
    .subtractByKey(rare)
    .map(lambda x: (x[0], 1))
    .countByKey()
)

# [(business,[(word,fre),(word,fre)...]),(business,[(word,fre),(word,fre)...])...])]
temp = (
    concatenate.map(lambda x: (x[0], (x[1], x[2])))
    .groupByKey()
    .mapValues(list)
    .persist(storageLevel=StorageLevel.MEMORY_AND_DISK)
)

# give number for each word
# ====>{word:number, word:number}
id_num_map = (
    temp.flatMap(lambda x: set([word for word, fre in x[1]]))
    .distinct()
    .zipWithIndex()
    .collectAsMap()
)
# ====>{number:word,number:word...}
change = {value: key for key, value in id_num_map.items()}


def word_number(word_fre_lst, id_num_map):
    wordnumber_lst = []
    for word_fre in word_fre_lst:
        number = id_num_map[word_fre[0]]
        wordnumber_lst.append((number, word_fre[1]))
    return wordnumber_lst


def TF_IDF(number_lst):
    max_fre = max([fre[1] for fre in number_lst])
    words = []
    for number_fre in number_lst:
        word_number = number_fre[0]
        fre = number_fre[1]
        if max_fre != 0:
            if merge[change[word_number]] != 0:
                TF_IDF_score = (
                    fre / max_fre * math.log(2, N / merge[change[word_number]])
                )
                words.append((word_number, TF_IDF_score))
    words.sort(key=lambda x: x[1], reverse=True)
    describe_words = words[0:200]
    return describe_words


# calculate TF*IDF
# ===>[(business,[(number,score),(number,score)...]),(business,[(number,score),(number,score)...])...])]
scores = (
    temp.mapValues(
        lambda x: word_number(x, id_num_map)
    )  # ====>[(business,[(number,fre),(number,fre)...]),(business,[(number,fre),(number,fre)...])...])]
    .map(lambda x: (x[0], TF_IDF(x[1])))
    .collect()
)

# endregion

# region user profile
# [(user,{b1,b2...}),(user,{b1,b2...}),(user,{b1,b2...})...]
users = rdd.map(lambda x: (x[0], x[1])).groupByKey().mapValues(set).collect()
# endregion


with open(model_file, "w") as f:
    business_words = {}
    for score in scores:
        business_words[score[0]] = list(set(word[0] for word in score[1]))
        business = {
            "type": "business",
            "business_id": score[0],
            "words": business_words[score[0]],
        }
        f.write(json.dumps(business) + "\n")

    for user in users:
        user_word = set()
        for business in user[1]:
            if business in business_words:
                user_word = set(business_words[business]).union(user_word)
        users_words = {"type": "user", "user_id": user[0], "words": list(user_word)}
        f.write(json.dumps(users_words) + "\n")
    del business_words

end = time.time()
print("Duration: " + str(end - start))
