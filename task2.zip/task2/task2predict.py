from pyspark import SparkContext, SparkConf
import sys
import json
import time

test_file = sys.argv[1]
model_file = sys.argv[2]
output_file = sys.argv[3]
conf = (
    SparkConf()
    .setAppName("inf553_hw3_task2predict")
    .set("spark.executor.memory", "4g")
    .set("spark.driver.memory", "4g")
)
sc = SparkContext(conf=conf)

start = time.time()

model = sc.textFile(model_file).map(json.loads)

business_words = (
    model.filter(lambda x: x["type"] == "business")
    .map(lambda b: (b["business_id"], set(b["words"])))
    .collectAsMap()
)

user_words = (
    model.filter(lambda x: x["type"] == "user")
    .map(lambda u: (u["user_id"], set(u["words"])))
    .collectAsMap()
)

# [(business,user),(business,user),(business,user)...]
test_pair = (
    sc.textFile(test_file)
    .map(json.loads)
    .map(lambda u_b: (u_b["business_id"],u_b["user_id"]))
    .collect()
)

with open(output_file,'w') as f:
    total_number = len(test_pair)
    identified_pairs = 0
    for pair in test_pair:
        if (pair[0] in business_words.keys()) and (pair[1] in user_words.keys()):
            business = business_words[pair[0]]
            user = user_words[pair[1]]
            molecular = len(business.intersection(user))
            denominator = ((len(business))**0.5)*((len(user))**0.5)
            if denominator != 0:
                similarity = molecular/denominator
                if similarity >= 0.01:
                    identified_pairs += 1
                    output = {"user_id":pair[1],"business_id":pair[0],"sim":similarity}
                    f.write(json.dumps(output) + '\n')

    print("accuracy:",identified_pairs/total_number)
    del test_pair
    del business_words
    del user_words
end = time.time()
print("Duration: " + str(end - start))
